
__title__ = 'woqlClient'
__description__ = 'woqlClient library for accessing the Terminus DB API'
__url__ = ''
__version__ = '0.0.1'
__build__ = 00
__author__ = 'Francesca Bitto'
__author_email__ = 'francesca@datachemist.com'
__license__ = 'Apache 2.0'
__copyright__ = 'Copyright 2019 datachemist'