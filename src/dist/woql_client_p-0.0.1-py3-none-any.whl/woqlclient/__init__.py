# Version of the realpython-reader package
"""
woqlClient Library
~~~~~~~~~~~~~~~~~~~~~
"""
name = "woqlclient"
__version__ = "0.0.1"
__all__ = ["idParser", "connectionCapabilities"]